/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-i18n/
 */
import { __ } from '@wordpress/i18n';

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from '@wordpress/block-editor';

/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';
import save from './save';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#edit
 *
 * @return {WPElement} Element to render.
 */

;

let qAmount = 0;
let questions = [];
let DOMquestions = [];
let qc;


export default function Edit() {

	const qType = React.useRef(null);
	const qContainer = React.useRef(null);
	const submitButton = React.useRef(null);

	qc = qContainer.current;


	const renderEditor = () =>{
		DOMquestions = questions.map((question) =>
		<div>
			<div>
				Question: {questions.indexOf(question)}
			</div>
			<div class='d-flex'>
				Type: {question.qTypeTitle}
				<button onClick={() => delQ(question)}>Delete Question</button>
			</div>
			<div>
				Question title
				<input type={"text"} onChange={question.title = handleTextInputChange}></input>
			</div>
			<div>
				Question description
				<input type={"text"} onChange={question.desc = handleTextInputChange}></input>
			</div>
			<button onClick={() => question.addS(question)}>Add a solution</button>
			<div>
			{		
					question.solutions.map(s => 
						question.genS(question, s)
					)	
			}
			</div>
		</div>
	);
	ReactDOM.render(<div class='w-100'>{DOMquestions}</div>, qc);
	}

	const addQ = () => {
		let t = qType.current.value;

		if(t=='paa')
		{
			addpaaQ();
		}
		else if(t=='mc')
		{
			addmcQ();
		}
		else if(t=='ff')
		{
			addffQ();
		}
		else if(t=='dad')
		{
			adddadQ();
		}
		else
		{
			alert("ERROR: invalid question type");
		}


		renderEditor();
	}

	const delQ = (question) =>{
		questions.splice(questions.indexOf(question),1);
		renderEditor();
	}

	const delS = (question, solution) =>{
		question.solutions.splice(question.solutions.indexOf(solution), 1);
		renderEditor();
	}

	const handleTextInputChange = (e) =>
	{
		return (e.target.value);
	}


	const addpaaQ = () => {
		
		let q = {
			type: "paa",
			qTypeTitle: "Pick an answer",
			addS: addpaaS,
			genS: genpaaS,
			solutions: [],
			sAmount: 0,
		};

		questions.push(q);
	};

	const addpaaS = (question) =>{
		question.solutions.push({
			sTitle: null, 
			correct: false

		})
		renderEditor();
	}

	const genpaaS = (question, solution) =>{
		return (
			<div class='d-flex align-items-center'>
				<div>{question.solutions.indexOf(solution)} :</div>
				<div><input type="text" onChange={solution.sTitle = handleTextInputChange}></input></div>
				<div>True: <input type="checkbox"></input></div>
				<div><button onClick={() => delS(question, solution)}>Delete solution</button></div>
			</div>
		)
	}


	const addmcQ = () => {
		let q = {
			type: "mc",
			qTypeTitle: "Multiple choice",
			addS: addmcS,
			solutions: []
		};

		questions.push(q);

		qAmount = qAmount+1;	
	};

	const addmcS = () =>{
		alert("MC SOLUTION")
	}

	const addffQ = () => {
		let q = {
			type: "ff",
			qTypeTitle: "Free fill",
			addS: addffS,
			solutions: []

		};

		questions.push(q);

		qAmount = qAmount+1;	
	};

	const addffS = () =>{
		alert("FF SOLUTION")
	}

	const adddadQ = () => {
		let q = {
			type: "dad",
			qTypeTitle: "Drag and drop",
			addS: adddadS,
			solutions: []

		};

		questions.push(q);

		qAmount = qAmount+1;	
	};

	const adddadS = () =>{
		alert("dad SOLUTION")
	}

	const submit = () =>{
		console.log(questions)
	}

	  
	return (
		<sincoequiz { ...useBlockProps() }>
			{<section>
				<div class="">
					<label for="title">Quiz Title</label>
					<div>
					<input name='title' type="text"></input>
					</div>
				</div>
				<div>
					<label for="desc">Quiz description:</label>
					<div>
					<textarea name='desc'></textarea>
					</div>
				</div>
				<div class='row'>
					<button onClick={addQ}>Add a new question</button>
					<select ref={qType}>
						<option selected value='paa'>Pick an answer</option>
						<option  value='mc'>Multiple choice</option>
						// <option  value='ff'>Free fill</option> hard to implement and pretty useles
						<option  value='dad'>Drag and drop</option>
					</select>
				</div>
				<div ref={qContainer}>

				</div>
				<button ref={submitButton} onClick={submit}> submit</button>
			</section> 
			}
		</sincoequiz>
	);
}




